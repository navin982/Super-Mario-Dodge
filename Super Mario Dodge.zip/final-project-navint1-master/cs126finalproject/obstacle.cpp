#include "obstacle.h"

void Obstacle::update() {
	//moves sideways (right to left) 
	x += velocity_x;
}