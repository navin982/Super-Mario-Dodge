Used a sound library (ofSoundPlayer). 
Made a sound play when the .exe is launched. 
Used the ofTrueTypeFont library to display the name
of the game.
Used ofImage library to display a background.

# **Week 1 (Due 4/18)**

Made a player cpp and header. The hard part for this was getting the physics to work. 
It took some revision to get the variables I defined in the obstacle file to work
with the ofApp file and make my guy fall where I wanted him too. I had alot of problems trying to get the include to work, but 
got it eventually. Making him jump required tweaking the acceleration. Much of this type of thing was new to me, so it took 
a while for me to get it all working together. 

The obstacle files were much more straight forward as all I had to do was make the obstacle move left 
(by changing the x velocity). Making the block spawn was kind of hard but got it after looking at how 
ofSnake worked (I used the same randomize mechanism). 

Next thing I had to do was make the actual collision. So if an obstacle hits my player the game registers that.

I need to make a spawn delay so the blocks don't spawn to close to each other. I did this by making them wait 30 frames
before spawning another block. 

# **Week 2 (Due 4/25)**

I added states to the game (START, OVER, RUNNING). Implemeting these was not too bad, I just had to be aware of what I was wrapping in what if statement.
I also made a score counter that every time a pipe went off screen it would increment. 
I also had to deal with memory. Making sure the pipes that left the screen were taken care of (acomplished using pop front). 
Another problem I dealt with was playing deep sea.mp3 whenever a new game is started. I tried to do this using Sleep, but it did not work. So eventually,
I just made a method musicTimer() which played the song when deepsea timer was 0. 

Also had to draw in the actual sprites of Mario and the obstacacles rather than just a built in rectangle. Initially, when I did this the collision box
for Mario was too big and I wasn't sure how to fix it until I realized I could just make the player_rect_collision box smaller than the actual size of 
mario. 

Next thing I had to implement was a puase screen. This was done by adding another enum state "PAUSE". I was running into some problems in this, because
when I paused it would go to an entire new screen and get rid of the whole game, which I wanted to stay. 

After I got the pause screen down I made a instructions screen which was done a similar way but only when at the start screen.

The next thing I had to implement is a star that gives invincibility when you touch it. This was hard because I had to create a whole new class for star
and give it properties through out the ofApp.cpp which make it so you ignore pipes. I ended up adding an attribute to the player class called invincible so 
when the play intersects with the star "invincible" is turned on for 10 seconds, and made it so that you could only reach game over when the invincible counter
reached 0 and you intersected with a pipe. It was hard coming up with how to do itm but once I came up with how to do it implementing it was not so bad. 

# **Final Week (Due 4/30)**

I had to make a vector which stored the previous rounds scores. This was not that hard to do as I just needed to create a vecotr of previous scores and whenever the player intersected with
the pipe call push back on it.

I had  a white border around my star item for some reason and it was not going away even with changing pictures. Eventually, I came to the conclusion that 
I can go through the pixels and manually change the color.

I wanted to make the background flash random colors when I get the star. This was not that difficult to do as I already did something similar with
the musicTimer().Insted of the RBG values I called the method in ofSetColor. I was having trouble with that, but eventually got it to work.

After this is done all the core game mechanics have been finished. Now I just need to beautify everything by adding sounds, fixing text, etc. This
should be pretty easy. 
I also need to make my code more cleanable and write some tests.

Writing tests was very difficult, because alot of the things I could not test for. 