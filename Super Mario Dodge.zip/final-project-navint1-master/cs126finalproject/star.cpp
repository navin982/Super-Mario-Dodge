#include "star.h"

void Star::update() {
	x += velocity_x;
}