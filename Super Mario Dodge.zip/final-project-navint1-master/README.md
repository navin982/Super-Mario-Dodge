# **Super Mario Dodge** 

**How to Play** 
Mario needs to dodge incoming pipes, otherwise he dies.
You can do this by jumping (press 'space').
You can also pause the game while it is running by pressing 'P'.
Be sure to collect stars which makes Mario invincible for a brief
time period. 

**Created by Navin Tiwary**

*sounds and sprites belong to Nintendo, specifically 
many sounds come from the game Super Mario Sunshine. 
